<?php
include 'connent.php';
$id =$_POST['id'];
$Name=$_POST['Name'];
$Email=$_POST['Email'];
$Password=$_POST['Password'];
$Address=$_POST['Address'];
$City=$_POST['City'];
$country=$_POST['country'];
$Zip=$_POST['Zip'];
$Gender=$_POST['Gender'];
$Age=$_POST['Age'];

$sql = "UPDATE Mydoc SET Name='$Name',Email='$Email',Password='$Password',Address='$Address',City='$City',country='$country',Zip='$Zip',Gender='$Gender',Age='$Age'   WHERE id='$id' ";

if (mysqli_query($conn, $sql)) {
  include 'main_page_alart.php';
} else {
  echo "Error updating record: " . mysqli_error($conn);
}

?>