<?php
include 'connent.php';


$Email=$_POST['Email'];
$Password=$_POST['Password'];

$sql = "SELECT * FROM Mydoc WHERE Email='$Email' AND Password='$Password' ";
		 $result = mysqli_query($conn, $sql);

				 if (mysqli_num_rows($result) > 0) {
					session_start();
					$_SESSION['checked'] = "loging";
					header('Location: main_page.php');
				}else{
					header('Location: index.php');
				}
?>