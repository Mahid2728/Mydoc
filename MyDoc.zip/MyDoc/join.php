<?php
include 'connent.php';

$Name=$_POST['Name'];
$Email=$_POST['Email'];
$Password=$_POST['Password'];
$Address=$_POST['Address'];
$City=$_POST['City'];
$country=$_POST['country'];
$Zip=$_POST['Zip'];
$Gender=$_POST['Gender'];
$Age=$_POST['Age'];

$sql = "INSERT INTO Mydoc (Name, Email , Password, Address,City,country,Zip,Gender,Age)
          VALUES ('$Name', '$Email', '$Password','$Address', '$City', '$country','$Zip', '$Gender', '$Age')";

          if ($conn->query($sql) === TRUE) {
            include 'alart.php';
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }

          
?>