<?php
include 'connent.php';
$id=$_GET['id'];

            $sql = "DELETE FROM Mydoc WHERE id='$id' ";

				if (mysqli_query($conn, $sql)) {
                    include 'main_page_remove_alart.php';
				} else {
				  echo "Error deleting record: " . mysqli_error($conn);
				}

        ?>