-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2021 at 12:10 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `mydoc`
--

CREATE TABLE `mydoc` (
  `id` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Address` varchar(60) NOT NULL,
  `City` varchar(20) NOT NULL,
  `country` varchar(2) NOT NULL,
  `Zip` int(5) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Age` int(2) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mydoc`
--

INSERT INTO `mydoc` (`id`, `Name`, `Email`, `Password`, `Address`, `City`, `country`, `Zip`, `Gender`, `Age`, `date`, `status`) VALUES
(2, 'Mahid', 'mahid6258@gmail.com', '62985292', 'bogra', 'bogra', 'BD', 5800, 'Male', 18, '2021-10-18 22:05:56', 1),
(3, 'al alif', 'alif268@gmail.com', '00123', '1526', '475', 'CA', 520806, 'Male', 22, '2021-10-18 22:05:56', 1),
(24, 'alif', 'alif2728@gmail.com', '123', 'bogra', 'bogra', 'BD', 5800, 'Male', 18, '2021-10-18 22:05:56', 1),
(27, 'a', 'a@gmail.com', 'a', 'a', 'a', 'US', 0, 'Male', 12, '2021-10-18 22:07:09', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mydoc`
--
ALTER TABLE `mydoc`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mydoc`
--
ALTER TABLE `mydoc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
