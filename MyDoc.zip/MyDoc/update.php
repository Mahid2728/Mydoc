<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>MyDoc</title>
  </head>
  <body>
  <?php  
  include 'connent.php';
$id=$_GET['id'];

$sql = "SELECT * FROM Mydoc WHERE id='$id'" ;
$result = mysqli_query($conn, $sql);


while($row = mysqli_fetch_assoc($result)) {
	$now=$row;
}
?>
 <nav class="navbar navbar-expand-lg navbar-dark  bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">My Doc</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About US</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            More
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Photoshop</a></li>
                            <li><a class="dropdown-item" href="#">Graphic Disign</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Web Desing</a></li>
                            <li><a class="dropdown-item" href="#">Web Wevelopment</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">MS Office</a></li>
                        </ul>
                    </li>
                </ul>
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-secondary" type="submit">Search</button>
                </form>
                <div class="mx-2">
                    <button type="button" class="btn btn-light" data-bs-toggle="modal"
                        data-bs-target="#LoginModal"><a href="log_out.php" class="text-decoration-none text-dark">logout</a></button>
                </div>
            </div>
        </div>
    </nav>

<div class="row py-5">
    <div class="col"></div>
    <div class="col-md-6">
  <form class="row g-3 form-control" action="update2.php" method="POST" >
  <h2>Update Now</h2>
  <input type="hidden" name="id" value="<?php echo $now['id']; ?>">

                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="Name" value="<?php echo $now['Name']; ?>">


                            <label for="inputEmail4" class="form-label">Email</label>
                            <input type="email" class="form-control" id="inputEmail4" name="Email" value="<?php echo $now['Email']; ?>">

                            <label for="inputPassword4" class="form-label">Password</label>
                            <input type="password" class="form-control" id="inputPassword4" name="Password" value="<?php echo $now['Password']; ?>">

                            <label for="inputAddress" class="form-label">Address</label>
                            <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St" name="Address" value="<?php echo $now['Address']; ?>">

                            <label for="inputCity" class="form-label">City</label>
                            <input type="text" class="form-control" id="inputCity"  name="City" value="<?php echo $now['City']; ?>">

                            <label for="inputState" class="form-label">country</label>
                            <select id="inputState" class="form-select" name="country" value="<?php echo $now['country']; ?>">
                                <option selected>Choose...</option>
                                <option>US</option>
                                <option>UK</option>
                                <option>BD</option>
                                <option>CA</option>
                                <option>AU</option>
                            </select>

                            <label for="inputZip" class="form-label">Zip</label>
                            <input type="text" class="form-control" id="inputZip" name="Zip" value="<?php echo $now['Zip']; ?>">
 
                            <label for="inputState2" class="form-label">Gender</label>
                            <select id="inputState2" class="form-select" name="Gender" value="<?php echo $now['Gender']; ?>">
                                <option selected>Choose...</option>
                                <option>Male</option>
                                <option>Female</option>
                            </select>
                            
                            <label for="inputZip2" class="form-label">Age</label>
                            <input type="number" class="form-control" id="inputZip2" name="Age" value="<?php echo $now['Age']; ?>">

                            <button type="submit" class="btn btn-primary">Update</button>
                    </form>

                    </div>
    <div class="col"></div>
</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>